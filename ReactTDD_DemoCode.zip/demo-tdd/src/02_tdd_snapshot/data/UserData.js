export default {
    "users": [
        {
            "name": "Ram",
            "location": "Bangalore"
        },
        {
            "name": "Raj",
            "location": "Pune"
        },
        {
            "name": "Vinay",
            "location": "Kochi"
        }
    ]
}